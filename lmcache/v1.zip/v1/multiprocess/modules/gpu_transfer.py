# SPDX-License-Identifier: Apache-2.0
"""GPU-based KV cache transfer operations for the MPCacheEngine."""

# Standard
from dataclasses import dataclass
from itertools import islice
from typing import Generator
import time

# First Party
from lmcache import torch_dev, torch_device_type
from lmcache.logging import init_logger
from lmcache.utils import (
    EngineType,
    _lmcache_nvtx_annotate,
    check_interprocess_event_support,
)
from lmcache.v1.distributed.api import (
    MemoryLayoutDesc,
    ObjectKey,
)
from lmcache.v1.gpu_connector.gpu_ops import (
    lmcache_memcpy_async_d2h,
    lmcache_memcpy_async_h2d,
)
from lmcache.v1.gpu_connector.utils import LayoutHints
from lmcache.v1.memory_management import MemoryObj
from lmcache.v1.mp_observability.event import Event, EventType
from lmcache.v1.multiprocess.custom_types import (
    IPCCacheEngineKey,
    KVCache,
)
from lmcache.v1.multiprocess.engine_context import MPCacheEngineContext
from lmcache.v1.multiprocess.engine_module import (
    HandlerSpec,
    ThreadPoolType,
)
from lmcache.v1.multiprocess.gpu_context import GPUCacheContext
from lmcache.v1.multiprocess.native_completion import (
    DeviceHostFuncDispatcher,
    submit_callback_to_stream,
)
from lmcache.v1.multiprocess.protocols.base import RequestType
import lmcache.c_ops as lmc_ops

logger = init_logger(__name__)


def get_layout_desc(gpu_context: GPUCacheContext, num_tokens: int) -> MemoryLayoutDesc:
    """Get the memory layout description for a given GPU context and number of tokens.

    Supports multiple KV layer groups with different shapes and dtypes.

    Args:
        gpu_context: The GPU cache context containing the KV cache information.
        num_tokens: The number of tokens to determine the layout for.

    Returns:
        MemoryLayoutDesc: The memory layout description containing shapes and dtypes.
    """
    num_groups = gpu_context.kv_layer_groups_manager.num_groups
    shapes = [
        gpu_context.get_kv_buffer_shape(num_tokens, group_idx)
        for group_idx in range(num_groups)
    ]
    dtypes = [
        gpu_context.kv_layer_groups_manager.kv_layer_groups[group_idx].dtype
        for group_idx in range(num_groups)
    ]
    return MemoryLayoutDesc(shapes=shapes, dtypes=dtypes)


def batched_iteration(lst: list, batch_size: int) -> Generator[tuple, None, None]:
    """Utility function to iterate over a list in batches.

    Args:
        lst: The list to iterate over.
        batch_size: The size of each batch.

    Yields:
        Batches of the list as tuples.

    Raises:
        ValueError: If batch_size is less than 1.
    """
    if batch_size < 1:
        raise ValueError("batch size must be at least one")
    it = iter(lst)
    while batch := tuple(islice(it, batch_size)):
        yield batch


@dataclass
class GPUContextEntry:
    """Registered GPU context metadata for a single worker instance.

    Args:
        gpu_context: The GPU cache context managing shape and pointers
            to vLLM GPU KV cache tensors.
        model_name: The name of the model associated with this KV cache.
        world_size: The world size associated with this KV cache.
    """

    gpu_context: GPUCacheContext
    model_name: str
    world_size: int


class GPUTransferModule:
    """Handles GPU-based KV cache transfer operations.

    Owns GPU context registrations and provides handlers for
    register, unregister, store, and retrieve of GPU KV caches.

    Args:
        ctx: The shared engine context.
    """

    def __init__(self, ctx: MPCacheEngineContext) -> None:
        self._ctx = ctx
        self._gpu_contexts: dict[int, GPUContextEntry] = {}

        # Route finish_write / finish_read_prefetched through a C++ host
        # callback so the driver thread doesn't acquire the GIL.
        self._device_host_func_dispatcher = DeviceHostFuncDispatcher()
        self._device_host_func_dispatcher.register(
            "finish_write",
            self._ctx.storage_manager.finish_write,
            payload_type=list[ObjectKey],
        )
        self._device_host_func_dispatcher.register(
            "finish_read_prefetched",
            self._ctx.storage_manager.finish_read_prefetched,
            payload_type=list[ObjectKey],
        )
        self._device_host_func_dispatcher.start()

    @property
    def context(self) -> MPCacheEngineContext:
        """Return the shared engine context. Exposed for testing only."""
        return self._ctx

    @property
    def gpu_contexts(self) -> dict[int, GPUContextEntry]:
        """Per-instance GPU context registry."""
        return self._gpu_contexts

    def get_handlers(self) -> list[HandlerSpec]:
        """Return handler specs for all request types this module serves.

        Returns:
            A list of HandlerSpec entries mapping request types to
            their handler callables and thread pool assignments.
        """
        return [
            HandlerSpec(
                RequestType.REGISTER_KV_CACHE,
                self.register_kv_cache,
                ThreadPoolType.SYNC,
            ),
            HandlerSpec(
                RequestType.UNREGISTER_KV_CACHE,
                self.unregister_kv_cache,
                ThreadPoolType.SYNC,
            ),
            HandlerSpec(
                RequestType.STORE,
                self.store,
                ThreadPoolType.AFFINITY,
            ),
            HandlerSpec(
                RequestType.RETRIEVE,
                self.retrieve,
                ThreadPoolType.AFFINITY,
            ),
        ]

    def report_status(self) -> dict:
        """Return GPU transfer module status information.

        Returns:
            A dict containing registered GPU instance IDs and
            per-instance KV cache layout metadata.
        """
        registered_gpu_ids: list[int] = []
        gpu_context_meta: dict[str, dict] = {}

        for instance_id, entry in self._gpu_contexts.items():
            registered_gpu_ids.append(instance_id)
            ctx = entry.gpu_context
            gpu_context_meta[str(instance_id)] = {
                "model_name": entry.model_name,
                "world_size": entry.world_size,
                "kv_cache_layout": {
                    "num_layers": ctx.num_layers,
                    "inference_engine_logical_block_size": (
                        ctx.kv_layer_groups_manager.inference_engine_logical_block_size
                    ),
                    "group_physical_block_sizes": ctx.group_physical_block_sizes,
                    "group_compress_ratios": ctx.group_compress_ratios,
                    "hidden_dim_sizes": str(ctx.hidden_dim_sizes),
                    "dtype": str(ctx.dtype),
                    "is_mla": ctx.is_mla,
                    "num_blocks": ctx.num_blocks,
                    "gpu_kv_format": ctx.gpu_kv_format_name,
                    "gpu_kv_shape": ctx.gpu_kv_shape,
                    "gpu_kv_concrete_shape": ctx.concrete_gpu_kv_shape,
                    "attention_backend": ctx.attention_backend,
                    "cache_size_per_token": ctx.cache_size_per_token(),
                },
            }

        return {
            "registered_gpu_ids": registered_gpu_ids,
            "gpu_context_meta": gpu_context_meta,
        }

    def close(self) -> None:
        """Release GPU resources owned by this module."""
        # Stop the drain thread before storage_manager.close() so any
        # in-flight completions reach a live storage manager.
        self._device_host_func_dispatcher.stop()

        had_contexts = len(self._gpu_contexts) > 0
        self._gpu_contexts.clear()
        if had_contexts:
            torch_dev.empty_cache()

    def register_kv_cache(
        self,
        instance_id: int,
        kv_caches: KVCache,
        model_name: str,
        world_size: int,
        engine_type: EngineType,
        layout_hints: LayoutHints,
    ) -> None:
        """Register the KV cache tensors for a given GPU instance ID.

        Args:
            instance_id: The GPU instance ID (such as PID).
            kv_caches: The KV cache tensor wrappers from the
                serving engine.
            model_name: The name of the model associated with this KV cache.
            world_size: The world size associated with this KV cache.
            engine_type: Which serving engine produced the caches.
                Forwarded to GPUCacheContext for format detection.
            layout_hints: See LayoutHints.  Forwarded to
                GPUCacheContext for GPU KV format detection.
        """
        if instance_id in self._gpu_contexts:
            logger.warning(
                "Instance %s's KV cache is already registered, "
                "skipping the new registration",
                instance_id,
            )
            return

        gpu_context = GPUCacheContext(
            kv_caches,
            self._ctx.chunk_size,
            layout_hints=layout_hints or None,
            engine_type=engine_type,
        )
        self._gpu_contexts[instance_id] = GPUContextEntry(
            gpu_context=gpu_context,
            model_name=model_name,
            world_size=world_size,
        )

        layout_desc = get_layout_desc(gpu_context, self._ctx.chunk_size)
        self._ctx.layout_desc_registry.register(model_name, world_size, layout_desc)

        logger.info(
            "Registered KV cache for GPU ID %d with %d layers",
            instance_id,
            gpu_context.num_layers,
        )

    def unregister_kv_cache(self, instance_id: int) -> None:
        """Unregister the KV cache tensors for a given GPU instance ID.

        Args:
            instance_id: The GPU instance ID (such as PID).
        """
        entry = self._gpu_contexts.pop(instance_id, None)
        if entry is None:
            logger.warning(
                "No registered GPU context found for instance ID %d", instance_id
            )
            return

        self._ctx.layout_desc_registry.unregister(entry.model_name, entry.world_size)
        logger.info("Unregistered KV cache for GPU ID %d", instance_id)
        torch_dev.empty_cache()

    @_lmcache_nvtx_annotate
    def store(
        self,
        key: IPCCacheEngineKey,
        instance_id: int,
        gpu_block_ids: list[int],
        event_ipc_handle: bytes,
    ) -> tuple[bytes, bool]:
        """
        将 GPU KV cache 块存储到 CPU 内存。

        这是 LMCache 多进程模式的核心存储方法，由 LMCacheMPConnector 在模型执行后调用。

        ┌─────────────────────────────────────────────────────────────────────────┐
        │                           Store 处理流程                                 │
        ├─────────────────────────────────────────────────────────────────────────┤
        │                                                                         │
        │ Step 1: 接收消息                                                        │
        │   - MessageQueueServer 反序列化消息                                    │
        │   - 解析 [key, instance_id, gpu_block_ids, event_ipc_handle]          │
        │                                                                         │
        │ Step 2: 获取 GPU Context                                               │
        │   - entry = self._gpu_contexts[instance_id]                           │
        │   - gpu_context 包含 vLLM KV cache 指针                               │
        │                                                                         │
        │ Step 3: 等待 vLLM CUDA Event                                          │
        │   - vllm_event = Event.from_ipc_handle(event_ipc_handle)             │
        │   - vllm_event.wait(stream)  # 确保 vLLM 计算完成                     │
        │                                                                         │
        │ Step 4: 预留 CPU 存储空间                                              │
        │   - storage_manager.reserve_write(obj_keys, layout_desc)             │
        │   - 返回 memory_obj（CPU 内存对象）                                    │
        │                                                                         │
        │ Step 5: GPU → CPU 数据传输 (D2H)                                       │
        │   5.1 GPU paged KV buffer → GPU tmp buffer                           │
        │       lmc_ops.multi_layer_block_kv_transfer(D2H)                       │
        │   5.2 GPU tmp buffer → CPU memory_obj                                 │
        │       lmcache_memcpy_async_d2h()                                       │
        │                                                                         │
        │ Step 6: 完成写入                                                       │
        │   - event.record() 记录完成事件                                       │
        │   - submit_callback_to_stream("finish_write", keys)                  │
        │                                                                         │
        │ Step 7: 返回结果                                                        │
        │   return event.ipc_handle(), True                                     │
        │                                                                         │
        └─────────────────────────────────────────────────────────────────────────┘

        数据流向:
            vLLM GPU (Paged KV Buffer)
                    │
                    ▼ D2H Kernel + memcpy_d2h
            LMCache Server GPU (Tmp Buffer)
                    │
                    ▼
            CPU MemoryObj (reserved)
                    │
                    ▼
            LMCache Storage Backend (CPU/Disk/Remote)

        Args:
            key: IPC key，用于定位要存储的 KV cache 块
            instance_id: GPU 实例 ID（通常是 vLLM Worker 的 PID）
            gpu_block_ids: vLLM 分配的 GPU block IDs，数据从这些位置读取
            event_ipc_handle: CUDA Event IPC 句柄，用于跨进程同步

        Returns:
            元组 (event.ipc_handle(), success):
            - event.ipc_handle(): 完成事件的 IPC 句柄，vLLM 端可等待
            - success: 存储操作是否成功

        Raises:
            ValueError: instance_id 未注册
            RuntimeError: 后端不支持 IPC event handles
        """
        st = time.perf_counter()
        obj_keys = self._ctx.resolve_obj_keys(key)

        entry = self._gpu_contexts.get(instance_id)
        if entry is None:
            raise ValueError(f"No GPU context registered for instance ID {instance_id}")
        gpu_context = entry.gpu_context
        model_name = entry.model_name

        # 计算每个 chunk 包含多少个 vLLM 逻辑块
        # blocks_per_chunk = chunk_size / logical_block_size
        # 对于压缩组，物理块数不同，但块索引与引擎共享
        blocks_per_chunk = (
            self._ctx.chunk_size
            // gpu_context.kv_layer_groups_manager.inference_engine_logical_block_size
        )

        with (
            torch_dev.device(gpu_context.device),
            torch_dev.stream(gpu_context.stream),
        ):
            check_interprocess_event_support()
            event = torch_dev.Event(interprocess=True)

            # 将 block_ids 暂存到 GPU
            all_block_ids_gpu = gpu_context.stage_block_ids(gpu_block_ids)

            if not hasattr(torch_dev.Event, "from_ipc_handle"):
                raise RuntimeError(
                    f"Backend '{torch_device_type}' does not support IPC event "
                    "handles (Event.from_ipc_handle not available). "
                    "Multiprocess IPC requires CUDA."
                )

            # Step 3: 等待 vLLM 端的 CUDA Event
            # 确保 vLLM 在该点之前的计算都已完成
            vllm_event = torch_dev.Event.from_ipc_handle(
                gpu_context.device, event_ipc_handle
            )
            vllm_event.wait(stream=gpu_context.stream)

            # 发布 Store 开始事件（用于可观测性）
            self._ctx.event_bus.publish(
                Event(
                    event_type=EventType.MP_STORE_SUBMITTED,
                    session_id=key.request_id,
                    metadata={"device": str(gpu_context.device)},
                )
            )

            self._ctx.event_bus.publish_on_stream(
                gpu_context.cupy_stream,
                Event(
                    event_type=EventType.MP_STORE_START,
                    session_id=key.request_id,
                    metadata={
                        "device": str(gpu_context.device),
                        "engine_id": instance_id,
                        "model_name": model_name,
                    },
                ),
            )

            reserved_dict: dict[ObjectKey, MemoryObj] = {}
            try:
                # Step 4: 预留 CPU 存储空间
                layout_desc = get_layout_desc(gpu_context, self._ctx.chunk_size)
                reserved_dict = self._ctx.storage_manager.reserve_write(
                    obj_keys, layout_desc, "new"
                )

                # Step 5: GPU → CPU 数据传输
                # 注意：存储不是批量的，因为某些 obj_keys 可能被跳过
                # 导致 block_ids 不连续，批处理需要 torch.cat 重新组装
                num_groups = gpu_context.kv_layer_groups_manager.num_groups
                for idx, obj_key in enumerate(obj_keys):
                    if obj_key in reserved_dict:
                        memory_obj = reserved_dict[obj_key]
                    else:
                        continue

                    # 计算当前 chunk 对应的 block IDs 范围
                    chunk_block_ids_gpu = all_block_ids_gpu[
                        idx * blocks_per_chunk : (idx + 1) * blocks_per_chunk
                    ]

                    # 5.1 GPU paged KV buffer → GPU tmp buffer (按 KV 层组)
                    for group_idx in range(num_groups):
                        tmp_buffer = gpu_context.get_tmp_chunk_gpu_buffer(group_idx)
                        group_kv_pointers = gpu_context.get_group_kv_pointers(group_idx)
                        # 物理 chunk 大小 = 逻辑 chunk 大小 / 压缩比
                        group_lmcache_chunk_size = gpu_context.get_physical_chunk_size(
                            group_idx
                        )
                        lmc_ops.multi_layer_block_kv_transfer(
                            group_kv_pointers,           # vLLM KV cache 指针
                            [tmp_buffer.data_ptr()],      # GPU tmp buffer
                            chunk_block_ids_gpu,           # block IDs
                            gpu_context.device,
                            lmc_ops.TransferDirection.D2H,  # D2H = Device to Host
                            gpu_context.get_shape_desc(group_idx),
                            group_lmcache_chunk_size,
                            gpu_context.gpu_kv_format_,
                            0,
                        )

                    # 5.2 GPU tmp buffer → CPU memory_obj
                    # 存储不是批量的，所以使用 chunk_idx=0
                    lmcache_memcpy_async_d2h(
                        gpu_context.get_tmp_gpu_buffer_flat(chunk_idx=0), memory_obj
                    )
            except Exception:
                logger.exception("Cannot store keys due to exception")
            finally:
                # Step 6: 完成写入
                event.record()  # 记录完成事件
                if reserved_dict:
                    # 提交回调通知 storage_manager 写入完成
                    submit_callback_to_stream(
                        gpu_context.cupy_stream,
                        "finish_write",
                        list(reserved_dict.keys()),
                    )
                # 计算传输总字节数
                total_bytes = (
                    next(iter(reserved_dict.values())).get_size() * len(reserved_dict)
                    if reserved_dict
                    else 0
                )
                # 发布 Store 结束事件
                self._ctx.event_bus.publish_on_stream(
                    gpu_context.cupy_stream,
                    Event(
                        event_type=EventType.MP_STORE_END,
                        session_id=key.request_id,
                        metadata={
                            "stored_count": len(reserved_dict),
                            "device": str(gpu_context.device),
                            "engine_id": instance_id,
                            "model_name": model_name,
                            "total_bytes": total_bytes,
                        },
                    ),
                )

        ed = time.perf_counter()
        if length := len(reserved_dict):
            logger.info(
                "Stored %d tokens in %.3f seconds",
                length * self._ctx.chunk_size,
                ed - st,
            )
        return event.ipc_handle(), True

    @_lmcache_nvtx_annotate
    def retrieve(
        self,
        key: IPCCacheEngineKey,
        instance_id: int,
        gpu_block_ids: list[int],
        event_ipc_handle: bytes,
        skip_first_n_tokens: int = 0,
    ) -> tuple[bytes, bool]:
        """
        从 CPU 内存检索 KV cache 并加载到 GPU 块。
        这是 LMCache 多进程模式的核心检索方法，由 LMCacheMPConnector 在模型执行前调用。

        Args:
            key: IPC key，用于定位要检索的 KV cache 块
            instance_id: GPU 实例 ID（通常是 vLLM Worker 的 PID）
            gpu_block_ids: vLLM 分配的 GPU block IDs，KV 数据加载到这些位置
            event_ipc_handle: CUDA Event IPC 句柄（当前 retrieve 不等待此事件）
            skip_first_n_tokens: 跳过写入的 token 数量，用于避免覆盖 APC 共享块

        Returns:
            元组 (event.ipc_handle(), success):
            - event.ipc_handle(): 完成事件的 IPC 句柄，vLLM 端可等待
            - success: 检索操作是否成功

        """
        st = time.perf_counter()
        obj_keys = self._ctx.resolve_obj_keys(key)

        entry = self._gpu_contexts.get(instance_id)
        if entry is None:
            raise ValueError(f"No GPU context registered for instance ID {instance_id}")
        gpu_context = entry.gpu_context
        model_name = entry.model_name

        # 发布 Retrieve 开始事件（用于可观测性）
        # 必须使用 publish()（非 publish_on_stream）确保 drain 线程在
        # MP_REQUEST_END 之前看到 MP_RETRIEVE_SUBMITTED
        self._ctx.event_bus.publish(
            Event(
                event_type=EventType.MP_RETRIEVE_SUBMITTED,
                session_id=key.request_id,
                metadata={"device": str(gpu_context.device)},
            )
        )
        # 异步非阻塞的进行log trace metric
        self._ctx.event_bus.publish_on_stream(
            gpu_context.cupy_stream,
            Event(
                event_type=EventType.MP_RETRIEVE_START,
                session_id=key.request_id,
                metadata={
                    "device": str(gpu_context.device),
                    "engine_id": instance_id,
                    "model_name": model_name,
                },
            ),
        )

        # 计算块大小和对齐
        # skip_*_in_chunk 使用引擎块单位（逻辑 token）
        ie_logical_block_size = (
            gpu_context.kv_layer_groups_manager.inference_engine_logical_block_size
        )
        blocks_per_chunk = self._ctx.chunk_size // ie_logical_block_size

        def _retrieve_loop(keys: list[ObjectKey], memory_objs: list[MemoryObj]) -> None:
            """
            执行 CPU → GPU 数据传输的内部循环。

            支持批量处理，按 batch_size 分批传输。
            处理 skip_first_n_tokens 以避免覆盖 APC 共享块。
            """
            _BATCH_SIZE = gpu_context.max_batch_size
            num_groups = gpu_context.kv_layer_groups_manager.num_groups
            for batch_idx, memory_obj_batch in enumerate(
                batched_iteration(memory_objs, batch_size=_BATCH_SIZE)
            ):
                batch_len = len(memory_obj_batch)
                chunk_start = batch_idx * self._ctx.chunk_size * _BATCH_SIZE
                chunk_end = chunk_start + self._ctx.chunk_size * batch_len

                # 计算有效起始位置（考虑 skip）
                effective_start = max(chunk_start, skip_first_n_tokens)
                if effective_start >= chunk_end:
                    # 整个批次都在 APC 范围内，跳过
                    continue

                # 计算要跳过的 token 数和块数
                skip_tokens_in_chunk = max(
                    0,
                    min(
                        effective_start - chunk_start,
                        self._ctx.chunk_size * batch_len - 1,
                    ),
                )
                if skip_tokens_in_chunk % ie_logical_block_size != 0:
                    logger.error(
                        "skip_first_n_tokens (%d) is not aligned to "
                        "inference_engine_logical_block_size (%d), "
                        "rounding down from %d tokens to %d blocks",
                        skip_first_n_tokens,
                        ie_logical_block_size,
                        skip_tokens_in_chunk,
                        skip_tokens_in_chunk // ie_logical_block_size,
                    )
                skip_blocks_in_chunk = skip_tokens_in_chunk // ie_logical_block_size

                # 计算当前批次对应的 chunk block IDs
                start_chunk_id = batch_idx * _BATCH_SIZE
                end_chunk_id = start_chunk_id + batch_len
                chunk_block_ids_gpu = all_block_ids_gpu[
                    start_chunk_id * blocks_per_chunk : end_chunk_id * blocks_per_chunk
                ]

                # Step 5: CPU → GPU 数据传输
                # 5.1 CPU memory_obj → GPU tmp buffer (批量)
                for chunk_idx, memory_obj in enumerate(memory_obj_batch):
                    lmcache_memcpy_async_h2d(
                        memory_obj,
                        gpu_context.get_tmp_gpu_buffer_flat(chunk_idx=chunk_idx),
                    )

                # 5.2 GPU tmp buffer → vLLM paged KV buffer (按 KV 层组)
                for group_idx in range(num_groups):
                    tmp_buffers = gpu_context.get_tmp_chunk_gpu_buffer_batched(
                        batch_len, group_idx
                    )
                    group_kv_pointers = gpu_context.get_group_kv_pointers(group_idx)
                    group_lmcache_chunk_size = gpu_context.get_physical_chunk_size(
                        group_idx
                    )

                    lmc_ops.multi_layer_block_kv_transfer(
                        group_kv_pointers,                    # vLLM KV cache 指针
                        [tb.data_ptr() for tb in tmp_buffers],  # GPU tmp buffers
                        chunk_block_ids_gpu,                    # block IDs
                        gpu_context.device,
                        lmc_ops.TransferDirection.H2D,       # H2D = Host to Device
                        gpu_context.get_shape_desc(group_idx),
                        group_lmcache_chunk_size,
                        gpu_context.gpu_kv_format_,
                        skip_blocks_in_chunk,                  # 跳过写入的块数
                    )

        with (
            torch_dev.device(gpu_context.device),
            torch_dev.stream(gpu_context.stream),
        ):
            # 将 block_ids 暂存到 GPU（循环前执行一次）
            all_block_ids_gpu = gpu_context.stage_block_ids(gpu_block_ids)

            check_interprocess_event_support()
            event = torch_dev.Event(interprocess=True)

            prefetched_keys: list[ObjectKey] = []
            retrieve_succeeded = False
            total_bytes = 0
            try:
                # Step 4: 读取预取数据
                with self._ctx.storage_manager.read_prefetched_results(
                    obj_keys
                ) as memory_objs:
                    if not memory_objs or len(memory_objs) != len(obj_keys):
                        logger.error("Some keys not found during retrieve!")
                        return event.ipc_handle(), False

                    prefetched_keys = obj_keys[: len(memory_objs)]
                    total_bytes = sum(mo.get_size() for mo in memory_objs)
                    # Step 5: 执行数据传输
                    _retrieve_loop(obj_keys, memory_objs)
                # 只有正常退出 with 块时才设置成功
                retrieve_succeeded = True
            except Exception:
                logger.exception("Cannot retrieve keys due to exception")
                return event.ipc_handle(), False
            finally:
                # Step 6: 完成读取
                event.record()  # 记录完成事件
                if retrieve_succeeded:
                    # 提交回调通知 storage_manager 读取完成
                    submit_callback_to_stream(
                        gpu_context.cupy_stream,
                        "finish_read_prefetched",
                        prefetched_keys,
                    )
                # 发布 Retrieve 结束事件
                self._ctx.event_bus.publish_on_stream(
                    gpu_context.cupy_stream,
                    Event(
                        event_type=EventType.MP_RETRIEVE_END,
                        session_id=key.request_id,
                        metadata={
                            "retrieved_count": len(prefetched_keys),
                            "device": str(gpu_context.device),
                            "engine_id": instance_id,
                            "model_name": model_name,
                            "cache_salt": key.cache_salt,
                            "total_bytes": total_bytes,
                        },
                    ),
                )
        tokens_retrieved = len(obj_keys) * self._ctx.chunk_size
        ed = time.perf_counter()
        logger.info(
            "Retrieved %d tokens in %.3f seconds",
            tokens_retrieved,
            ed - st,
        )

        return event.ipc_handle(), True
