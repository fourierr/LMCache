# SPDX-License-Identifier: Apache-2.0
"""HTTP endpoints to permanently pin / unpin KV cache tokens in L1.

These endpoints allow operators to prevent eviction of specific token
sequences from the L1 (CPU DRAM) cache.  Once pinned, the corresponding
KV cache chunks are excluded from LRU eviction until explicitly
unpinned.

Example usage (curl)::

    # Pin tokens
    curl -X POST http://localhost:8080/pin \\
        -H "Content-Type: application/json" \\
        -d '{
              "model_name": "meta-llama/Llama-3.1-8B",
              "world_size": 1,
              "token_ids": [1, 2, 3, 4, 5],
              "request_id": "manual-pin-001"
            }'

    # Unpin tokens
    curl -X POST http://localhost:8080/unpin \\
        -H "Content-Type: application/json" \\
        -d '{
              "model_name": "meta-llama/Llama-3.1-8B",
              "world_size": 1,
              "token_ids": [1, 2, 3, 4, 5],
              "request_id": "manual-pin-001"
            }'
"""

# Standard
from typing import Any

# Third Party
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

# First Party
from lmcache.logging import init_logger
from lmcache.v1.distributed.api import ipc_key_to_object_keys
from lmcache.v1.multiprocess.custom_types import IPCCacheEngineKey

logger = init_logger(__name__)

router = APIRouter()


class PinRequest(BaseModel):
    """HTTP request body for ``/pin`` and ``/unpin`` endpoints."""

    model_name: str
    world_size: int
    token_ids: list[int]
    request_id: str = "http-pin"
    cache_salt: str = ""
    worker_id: int | None = None


@router.post("/pin")
async def pin(request: Request, body: PinRequest) -> Any:
    """Permanently pin tokens in L1 cache.

    Pinned chunks are excluded from LRU eviction until explicitly
    unpinned via ``/unpin``.
    """
    engine = getattr(request.app.state, "engine", None)
    if engine is None:
        return JSONResponse(status_code=503, content={"error": "engine not initialized"})

    ctx = engine.context
    ipc_key = IPCCacheEngineKey(
        model_name=body.model_name,
        world_size=body.world_size,
        worker_id=body.worker_id,
        token_ids=tuple(body.token_ids),
        start=0,
        end=len(body.token_ids),
        request_id=body.request_id,
        cache_salt=body.cache_salt,
    )

    chunk_hashes = ctx.token_hasher.compute_chunk_hashes(body.token_ids)
    if not chunk_hashes:
        return {"pinned_tokens": 0}

    obj_keys = ipc_key_to_object_keys(ipc_key, chunk_hashes)
    hit_chunks = ctx.storage_manager.pin(obj_keys)
    pinned_tokens = hit_chunks * ctx.chunk_size

    logger.info(
        "HTTP pin: pinned %d tokens (%d chunks) for request %s",
        pinned_tokens,
        hit_chunks,
        body.request_id,
    )
    return {"pinned_tokens": pinned_tokens, "pinned_chunks": hit_chunks}


@router.post("/unpin")
async def unpin(request: Request, body: PinRequest) -> Any:
    """Release permanent pin references for tokens.

    Once all pin references for a chunk are released, it becomes
    eligible for LRU eviction again.
    """
    engine = getattr(request.app.state, "engine", None)
    if engine is None:
        return JSONResponse(status_code=503, content={"error": "engine not initialized"})

    ctx = engine.context
    ipc_key = IPCCacheEngineKey(
        model_name=body.model_name,
        world_size=body.world_size,
        worker_id=body.worker_id,
        token_ids=tuple(body.token_ids),
        start=0,
        end=len(body.token_ids),
        request_id=body.request_id,
        cache_salt=body.cache_salt,
    )

    chunk_hashes = ctx.token_hasher.compute_chunk_hashes(body.token_ids)
    if not chunk_hashes:
        return {"unpinned_chunks": 0}

    obj_keys = ipc_key_to_object_keys(ipc_key, chunk_hashes)
    ctx.storage_manager.unpin(obj_keys)

    logger.info(
        "HTTP unpin: released %d chunks for request %s",
        len(chunk_hashes),
        body.request_id,
    )
    return {"unpinned_chunks": len(chunk_hashes)}
